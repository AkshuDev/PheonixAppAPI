#    _____              .___       __________            _____   __           .__          ___.   .__
#   /     \ _____     __| _/____   \______   \___.__.   /  _  \ |  | __  _____|  |__   ____\_ |__ |  |__ ___.__._____
#  /  \ /  \\__  \   / __ |/ __ \   |    |  _<   |  |  /  /_\  \|  |/ / /  ___/  |  \ /  _ \| __ \|  |  <   |  |\__  \
# /    Y    \/ __ \_/ /_/ \  ___/   |    |   \\___  | /    |    \    <  \___ \|   Y  (  <_> ) \_\ \   Y  \___  | / __ \_
# \____|__  (____  /\____ |\___  >  |______  // ____| \____|__  /__|_ \/____  >___|  /\____/|___  /___|  / ____|(____  /
#         \/     \/      \/    \/          \/ \/              \/     \/     \/     \/           \/     \/\/          \/
#     ___ ___________                      .___             ___
#    /  / \_   _____/___  __ __  ____    __| _/___________  \  \
#   /  /   |    __)/  _ \|  |  \/    \  / __ |/ __ \_  __ \  \  \
#  (  (    |     \(  <_> )  |  /   |  \/ /_/ \  ___/|  | \/   )  )
#   \  \   \___  / \____/|____/|___|  /\____ |\___  >__|     /  /
#    \__\      \/                   \/      \/    \/        /__/






# __________.__                        .__           _________ __            .___.__
# \______   \  |__   ____  ____   ____ |__|__  ___  /   _____//  |_ __ __  __| _/|__| ____  ______
#  |     ___/  |  \_/ __ \/  _ \ /    \|  \  \/  /  \_____  \\   __\  |  \/ __ | |  |/  _ \/  ___/
#  |    |   |   Y  \  ___(  <_> )   |  \  |>    <   /        \|  | |  |  / /_/ | |  (  <_> )___ \
#  |____|   |___|  /\___  >____/|___|  /__/__/\_ \ /_______  /|__| |____/\____ | |__|\____/____  >
#                \/     \/           \/         \/         \/                 \/               \/

import os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
from PheonixAppAPI.pheonixapp.files.HashDecoderT import *

#Avail formats are -> [PSntx_H1]

op = input("Operation (Encode/Decode): ")
if op.lower() == "encode":
    msg = input("Message: ")
    type = input("Type: ")
    ComponentType = input("Component Type (Community, Enterprise, Pheonix Studios): ")
    if ComponentType.lower() in ["community", "enterprise", "pheonix studios", "pheonixstudios"]:
        print("\n\n\n\nEncoded Message: "+"\n"+Encode(msg, type, ComponentType).run())
    else:
        raise Exception("Only [Community, Enterprise, Pheonix Studios] are allowed as [Component Type]")
elif op.lower() == "decode":
    msg = input("Message: ")
    type = input("Type (Leave if don't have): ")
    print("\n\n\n\nDecoded Message: "+"\n"+Decode(msg, type).run())