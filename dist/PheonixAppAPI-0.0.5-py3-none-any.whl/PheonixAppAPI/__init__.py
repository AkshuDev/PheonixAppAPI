import os
from PheonixAppAPI.pheonixapp.files import PSSbridge

PSSbridge.API().CheckModules()

class API_vars:
    pass